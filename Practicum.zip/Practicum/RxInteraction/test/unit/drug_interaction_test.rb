require 'test_helper'

class DrugInteractionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
