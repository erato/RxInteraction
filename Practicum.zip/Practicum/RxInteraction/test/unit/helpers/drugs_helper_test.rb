require 'test_helper'

class DrugsHelperTest < ActionView::TestCase
end
