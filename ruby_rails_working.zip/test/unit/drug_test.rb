require 'test_helper'

class DrugTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
