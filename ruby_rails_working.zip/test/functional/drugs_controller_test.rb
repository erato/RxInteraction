require 'test_helper'

class DrugsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
