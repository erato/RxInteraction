module DrugsHelper
end
